# Skyward Sword Randomizer Map and Item Tracker
## made by j_im
An EmoTracker tracker package for [Skyward Sword Randomizer](https://github.com/lepelog/sslib)

Download EmoTracker [here](https://emotracker.net)

Usage: download from [Releases](https://github.com/j-imbo/ssrando_jim/releases/latest) and put into ../Documents/EmoTracker/packs/

To mark a dungeon as required, you can click on its label to change the color. Note: you MUST mark at least one dungeon as required for tracking anything that requires entering the past.

For options, click the gear cog at the top right of the items box.

Options Key:
||||
|-|-|-|
||Thunderhead: Thunderhead open/closed||
|Map: Dungeons on/off|Tablet: Overworld on/off|Goddess Chest: Goddess Chests on/off|
|Triforce: Main Quest on/off|Race Mode: Excluded dungeons on/off|Dodoh's Wheel: Sidequests on/off|
|Gratitude Crystal: Batreaux on/off|Harp: Silent Realms on/off|Bug Net: Minigames on/off|
